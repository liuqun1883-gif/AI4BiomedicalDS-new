# 论文与复现材料

- `多重检验_课程论文.pdf`：10 页中文课程论文，含 3 组科研图（10 个面板）、公式、参考文献与完整作业对照。
- `论文可编辑文本.md`：可编辑文字源；图的相对链接指向 figures。
- `figures/`：PDF、SVG 矢量图与 600 dpi PNG。
- `完整复现材料.zip`：论文、原始课程数据与 Notebook、运行脚本、全部结果表和核验记录。解压后按下述命令运行。

## 复现

从压缩包解压后的根目录运行（Python 3.12）：

```powershell
python -m pip install -r requirements-paper.txt
python .tmp/multiple-test/student-results/paper-20261110/run_analysis.py
python .tmp/multiple-test/student-results/paper-20261110/make_figures.py
python .tmp/multiple-test/student-results/paper-20261110/build_paper.py
```

统计与绘图可跨平台运行；PDF 排版脚本使用 Windows 的宋体、黑体。其他系统需将脚本中的字体路径替换为具有中文字符的字体路径。无需在 Jupyter 中运行 Notebook；统计脚本读取并复用其数值函数单元格。

锁定名单保持不变，脚本重跑时核对，不按验证结果更换候选。若希望建立全新的时间记录，可复制脚本至新的同级运行目录。新运行必须沿用先发现、再锁定、最后验证的顺序。数据与脚本均未提交 Git。

## 主要结果

发现集原始显著 1,694 项，Bonferroni 26 项，BH 535 项；10 个锁定候选中 7 个通过预定留出规则。模拟各重复 1,000 次，种子 42。

## 版式与署名

采用期刊研究论文结构与数学论文单栏排版，并借鉴照片中的多面板科研图呈现方式。这是中文课程复现稿，不宣称已达到 Science 正式英文投稿的所有要求。姓名、学号、单位未提供，因此未编造；提交前可在文字源中补充。AI 辅助内容及数据边界已在稿末说明。
